from __future__ import annotations

import os
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from uuid import uuid4

from dotenv import load_dotenv
from flask import Flask, g, jsonify, request, send_from_directory, session
from flask_cors import CORS
from werkzeug.security import check_password_hash, generate_password_hash

from bb_pix import BancoDoBrasilPixClient, PixIntegrationError
from pix_payload import parse_pix_payload


BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv("SECRET_KEY", "dev-only-change-me"),
    DATABASE=str(BASE_DIR / os.getenv("DATABASE_PATH", "instance/pixtapago.db")),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)
CORS(app, supports_credentials=True, origins=["http://localhost:5173"])


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        Path(app.config["DATABASE"]).parent.mkdir(parents=True, exist_ok=True)
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db() -> None:
    schema = (BASE_DIR / "schema.sql").read_text(encoding="utf-8")
    with app.app_context(), closing(get_db()) as db:
        db.executescript(schema)
        exists = db.execute("SELECT 1 FROM users LIMIT 1").fetchone()
        if not exists:
            db.execute(
                "INSERT INTO users (name, email, password_hash, role, active) VALUES (?, ?, ?, ?, 1)",
                ("Usuário Demonstração", "demo@pixtapago.com.br", generate_password_hash("pix123"), "Administrador"),
            )
        created = now_iso()
        owner_pix_key = os.getenv("BB_PIX_KEY", "hmtestes2@bb.com.br")
        db.execute(
            """INSERT INTO bank_accounts
               (actor, name, document, pix_key, balance_cents, created_at)
               VALUES ('dono', 'João', '***.482.910-**', ?, 850000, ?)
               ON CONFLICT(actor) DO UPDATE SET pix_key = excluded.pix_key""",
            (owner_pix_key, created),
        )
        db.execute(
            """INSERT OR IGNORE INTO bank_accounts
               (actor, name, document, pix_key, balance_cents, created_at)
               VALUES ('cliente', 'Pedro', '***.715.306-**', 'pedro@bancoaurora.com.br', 325000, ?)""",
            (created,),
        )
        remove_legacy_mock_data(db)
        reconcile_bank_payments(db)
        reclassify_standalone_pix(db)
        db.commit()


def remove_legacy_mock_data(db: sqlite3.Connection) -> None:
    """Remove somente registros reconhecidamente gerados pelo simulador antigo."""
    db.execute(
        """DELETE FROM receipts WHERE txid IN (
               SELECT txid FROM charges
               WHERE location LIKE 'mock://%' OR pix_copy_paste LIKE '%PIXTA-PAGO-SANDBOX%'
           )"""
    )
    db.execute(
        """DELETE FROM charges
           WHERE location LIKE 'mock://%' OR pix_copy_paste LIKE '%PIXTA-PAGO-SANDBOX%'"""
    )


def reconcile_bank_payments(db: sqlite3.Connection) -> None:
    """Recupera pagamentos bancários concluídos antes da vinculação automática da cobrança."""
    rows = db.execute(
        """SELECT t.e2eid, t.txid, t.amount_cents, t.description, t.created_at,
                  sender.name AS payer_name
           FROM bank_transactions t
           JOIN bank_accounts sender ON sender.id = t.sender_id
           JOIN charges charge ON charge.txid = t.txid
           WHERE t.txid <> '***'"""
    ).fetchall()
    for row in rows:
        db.execute(
            "UPDATE charges SET status = 'PAID', updated_at = ? WHERE txid = ?",
            (row["created_at"], row["txid"]),
        )
        db.execute(
            """INSERT OR IGNORE INTO receipts
               (e2eid, txid, payer_name, amount, origin, description, received_at)
               VALUES (?, ?, ?, ?, 'Cobrança Pix', ?, ?)""",
            (
                row["e2eid"], row["txid"], row["payer_name"],
                row["amount_cents"] / 100, row["description"], row["created_at"],
            ),
        )


def reclassify_standalone_pix(db: sqlite3.Connection) -> None:
    """Distingue Pix por chave de cobranças criadas por este sistema."""
    db.execute(
        """UPDATE receipts SET origin = 'Pix chave'
           WHERE origin = 'Pix avulso'
              OR (origin = 'Cobrança Pix' AND NOT EXISTS (
                    SELECT 1 FROM charges WHERE charges.txid = receipts.txid
                 ))"""
    )
def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return jsonify({"message": "Autenticação necessária."}), 401
        return view(*args, **kwargs)
    return wrapped


def charge_json(row: sqlite3.Row) -> dict:
    data = dict(row)
    data["amount"] = float(data["amount"])
    return data


def receipt_json(row: sqlite3.Row) -> dict:
    data = dict(row)
    data["amount"] = float(data["amount"])
    return data


def save_bb_payment(
    db: sqlite3.Connection,
    event: dict,
    fallback_txid: str | None = None,
    fallback_payer_name: str | None = None,
) -> bool:
    """Persiste uma confirmação do BB uma única vez, usando o EndToEndId."""
    e2eid = str(event.get("endToEndId") or "").strip()
    if not e2eid:
        return False

    txid = str(event.get("txid") or fallback_txid or "").strip() or None
    if txid and set(txid) == {"*"}:
        txid = None
    try:
        amount = float(event.get("valor", 0))
    except (TypeError, ValueError):
        amount = 0
    linked_charge = db.execute(
        "SELECT payer_name FROM charges WHERE txid = ?", (txid,)
    ).fetchone() if txid else None
    payer = (event.get("pagador") or {}).get("nome") or fallback_payer_name
    if not payer and linked_charge:
        payer = linked_charge["payer_name"]
    payer = payer or "Pagador não informado"
    received_at = event.get("horario") or now_iso()

    cursor = db.execute(
        """INSERT OR IGNORE INTO receipts
           (e2eid, txid, payer_name, amount, origin, description, received_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            e2eid,
            txid,
            payer,
            amount,
            "Cobrança Pix" if linked_charge else "Pix chave",
            event.get("infoPagador", ""),
            received_at,
        ),
    )
    if linked_charge:
        db.execute(
            "UPDATE charges SET status = 'PAID', updated_at = ? WHERE txid = ?",
            (received_at, txid),
        )
    return cursor.rowcount == 1


def sync_charge_with_bb(db: sqlite3.Connection, row: sqlite3.Row, client: BancoDoBrasilPixClient) -> int:
    """Atualiza uma cobrança local a partir da consulta oficial GET /cob/{txid}."""
    remote = client.get_charge(row["txid"], fallback_status=row["status"])
    new_receipts = 0
    for payment in remote["payments"]:
        if save_bb_payment(db, payment, row["txid"], row["payer_name"]):
            new_receipts += 1

    if remote["status"] != row["status"]:
        db.execute(
            "UPDATE charges SET status = ?, updated_at = ? WHERE txid = ?",
            (remote["status"], now_iso(), row["txid"]),
        )
    return new_receipts


def bank_account(actor: str) -> sqlite3.Row | None:
    return get_db().execute("SELECT * FROM bank_accounts WHERE actor = ?", (actor,)).fetchone()


def bank_transaction_json(row: sqlite3.Row, account_id: int) -> dict:
    direction = "OUT" if row["sender_id"] == account_id else "IN"
    return {
        "id": row["id"], "e2eid": row["e2eid"], "txid": row["txid"],
        "amount": row["amount_cents"] / 100, "description": row["description"],
        "paymentMethod": row["payment_method"], "createdAt": row["created_at"],
        "direction": direction,
        "counterparty": row["receiver_name"] if direction == "OUT" else row["sender_name"],
        "counterpartyKey": row["receiver_key"] if direction == "OUT" else row["sender_key"],
    }


def bank_transactions(account_id: int, limit: int = 30) -> list[dict]:
    rows = get_db().execute(
        """SELECT t.*, sender.name sender_name, sender.pix_key sender_key,
                         receiver.name receiver_name, receiver.pix_key receiver_key
           FROM bank_transactions t
           JOIN bank_accounts sender ON sender.id = t.sender_id
           JOIN bank_accounts receiver ON receiver.id = t.receiver_id
           WHERE t.sender_id = ? OR t.receiver_id = ?
           ORDER BY t.created_at DESC, t.id DESC LIMIT ?""",
        (account_id, account_id, limit),
    ).fetchall()
    return [bank_transaction_json(row, account_id) for row in rows]


class PixAlreadyPaidError(ValueError):
    pass


def settle_bank_pix(actor: str, pix_key: str, amount: float, description: str, method: str, idempotency_key: str, txid: str = "***") -> dict:
    db = get_db()
    sender = db.execute("SELECT * FROM bank_accounts WHERE actor = ?", (actor,)).fetchone()
    receiver = db.execute("SELECT * FROM bank_accounts WHERE lower(pix_key) = lower(?)", (pix_key,)).fetchone()
    if not sender:
        raise ValueError("Conta pagadora não encontrada.")
    if not receiver:
        raise ValueError("Chave Pix não encontrada.")
    if sender["id"] == receiver["id"]:
        raise ValueError("A chave informada pertence à própria conta.")
    amount_cents = round(float(amount) * 100)
    if amount_cents <= 0:
        raise ValueError("Informe um valor maior que zero.")
    previous = db.execute("SELECT * FROM bank_transactions WHERE idempotency_key = ?", (idempotency_key,)).fetchone()
    if previous:
        return next(item for item in bank_transactions(sender["id"], 100) if item["e2eid"] == previous["e2eid"])
    try:
        db.execute("BEGIN IMMEDIATE")
        if txid != "***":
            paid_transaction = db.execute(
                "SELECT 1 FROM bank_transactions WHERE txid = ? LIMIT 1",
                (txid,),
            ).fetchone()
            if paid_transaction:
                db.rollback()
                raise PixAlreadyPaidError("Esta cobrança Pix já foi paga.")
        current_balance = db.execute("SELECT balance_cents FROM bank_accounts WHERE id = ?", (sender["id"],)).fetchone()["balance_cents"]
        if current_balance < amount_cents:
            db.rollback()
            raise ValueError("Saldo insuficiente para concluir o Pix.")
        db.execute("UPDATE bank_accounts SET balance_cents = balance_cents - ? WHERE id = ?", (amount_cents, sender["id"]))
        db.execute("UPDATE bank_accounts SET balance_cents = balance_cents + ? WHERE id = ?", (amount_cents, receiver["id"]))
        e2eid = f"E00000000{datetime.now(timezone.utc):%Y%m%d%H%M}{uuid4().hex[:11].upper()}"
        db.execute(
            """INSERT INTO bank_transactions
               (e2eid, idempotency_key, sender_id, receiver_id, amount_cents, description, payment_method, txid, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (e2eid, idempotency_key, sender["id"], receiver["id"], amount_cents, description[:140], method, txid, now_iso()),
        )
        paid_at = now_iso()
        if txid != "***":
            db.execute(
                "UPDATE charges SET status = 'PAID', updated_at = ? WHERE txid = ?",
                (paid_at, txid),
            )
        if receiver["actor"] == "dono":
            receipt_txid = txid if txid != "***" else None
            db.execute(
                """INSERT OR IGNORE INTO receipts
                   (e2eid, txid, payer_name, amount, origin, description, received_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    e2eid, receipt_txid, sender["name"], amount_cents / 100,
                    "Cobrança Pix" if receipt_txid else "Pix chave",
                    description[:140], paid_at,
                ),
            )
        db.commit()
    except Exception:
        if db.in_transaction:
            db.rollback()
        raise
    return next(item for item in bank_transactions(sender["id"], 100) if item["e2eid"] == e2eid)


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "pixMode": "bb", "environment": "homologacao"})


@app.get("/api/bank/accounts/<actor>")
def get_bank_account(actor: str):
    account = bank_account(actor)
    if not account:
        return jsonify({"message": "Conta não encontrada."}), 404
    return jsonify({
        "actor": account["actor"], "name": account["name"], "document": account["document"],
        "pixKey": account["pix_key"], "balance": account["balance_cents"] / 100,
        "transactions": bank_transactions(account["id"]),
    })


@app.get("/api/bank/pix/resolve")
def resolve_bank_pix_key():
    pix_key = request.args.get("key", "").strip()
    receiver = get_db().execute(
        "SELECT name, document, pix_key FROM bank_accounts WHERE lower(pix_key) = lower(?)",
        (pix_key,),
    ).fetchone()
    if not receiver:
        return jsonify({"message": "Chave Pix não encontrada."}), 404
    return jsonify({"name": receiver["name"], "document": receiver["document"], "pixKey": receiver["pix_key"]})


def resolve_pix_payload_receiver(parsed: dict) -> tuple[sqlite3.Row, float | None, str]:
    """Localiza o recebedor de um QR estático ou de uma cobrança dinâmica criada pelo BB."""
    if parsed["pixKey"]:
        receiver = get_db().execute(
            "SELECT * FROM bank_accounts WHERE lower(pix_key) = lower(?)",
            (parsed["pixKey"],),
        ).fetchone()
        if not receiver:
            raise ValueError("Não foi possível localizar o recebedor deste código Pix.")
        return receiver, parsed["amount"], "***"

    charge = get_db().execute(
        "SELECT * FROM charges WHERE pix_copy_paste = ?",
        (parsed["payload"],),
    ).fetchone()
    receiver = bank_account("dono")
    if not charge or not receiver:
        raise ValueError("Esta cobrança dinâmica não foi gerada pelo PixTáPago.")
    return receiver, float(charge["amount"]), charge["txid"]


@app.post("/api/bank/pix/preview")
def preview_bank_pix_payload():
    payload = request.get_json(silent=True) or {}
    try:
        parsed = parse_pix_payload(str(payload.get("pix", "")))
    except ValueError as error:
        return jsonify({"message": str(error)}), 400
    try:
        receiver, amount, _txid = resolve_pix_payload_receiver(parsed)
    except ValueError as error:
        return jsonify({"message": str(error)}), 404
    return jsonify({
        "name": receiver["name"], "document": receiver["document"],
        "pixKey": parsed["pixKey"] or os.getenv("BB_PIX_KEY", receiver["pix_key"]),
        "amount": amount,
    })


@app.post("/api/bank/accounts/<actor>/pix/transfer")
def transfer_bank_pix(actor: str):
    payload = request.get_json(silent=True) or {}
    try:
        transaction = settle_bank_pix(
            actor, str(payload.get("pixKey", "")).strip(), float(payload.get("amount", 0)),
            str(payload.get("description", "")), "PIX_KEY",
            str(payload.get("idempotencyKey", "")).strip() or uuid4().hex,
        )
    except (TypeError, ValueError) as error:
        return jsonify({"message": str(error)}), 400
    return jsonify(transaction), 201


@app.post("/api/bank/accounts/<actor>/pix/pay")
def pay_bank_pix_code(actor: str):
    payload = request.get_json(silent=True) or {}
    try:
        parsed = parse_pix_payload(str(payload.get("pix", "")))
        receiver, code_amount, txid = resolve_pix_payload_receiver(parsed)
        amount = code_amount if code_amount is not None else float(payload.get("amount", 0))
        transaction = settle_bank_pix(
            actor, receiver["pix_key"], amount, str(payload.get("description", "")),
            "PIX_QR", str(payload.get("idempotencyKey", "")).strip() or uuid4().hex,
            txid,
        )
    except PixAlreadyPaidError as error:
        return jsonify({"message": str(error)}), 409
    except (TypeError, ValueError) as error:
        return jsonify({"message": str(error)}), 400
    return jsonify(transaction), 201


@app.post("/api/auth/login")
def login():
    payload = request.get_json(silent=True) or {}
    user = get_db().execute(
        "SELECT * FROM users WHERE lower(email) = lower(?)", (payload.get("email", ""),)
    ).fetchone()
    if not user or not user["active"] or not check_password_hash(user["password_hash"], payload.get("password", "")):
        return jsonify({"message": "E-mail ou senha não conferem."}), 401
    session.clear()
    session["user_id"] = user["id"]
    return jsonify({"id": user["id"], "name": user["name"], "email": user["email"], "role": user["role"]})


@app.post("/api/auth/logout")
def logout():
    session.clear()
    return "", 204


@app.get("/api/auth/me")
@login_required
def me():
    user = get_db().execute("SELECT id, name, email, role FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    return jsonify(dict(user))


@app.get("/api/dashboard")
@login_required
def dashboard():
    db = get_db()
    today = datetime.now(timezone.utc).date().isoformat()
    month = datetime.now(timezone.utc).strftime("%Y-%m")
    received_today = db.execute("SELECT COALESCE(SUM(amount), 0) value FROM receipts WHERE substr(received_at, 1, 10) = ?", (today,)).fetchone()["value"]
    received_month = db.execute("SELECT COALESCE(SUM(amount), 0) value FROM receipts WHERE substr(received_at, 1, 7) = ?", (month,)).fetchone()["value"]
    pending = db.execute("SELECT COUNT(*) value FROM charges WHERE status = 'ACTIVE'").fetchone()["value"]
    paid = db.execute("SELECT COUNT(*) value FROM charges WHERE status = 'PAID'").fetchone()["value"]
    recent = db.execute("SELECT * FROM charges ORDER BY created_at DESC LIMIT 5").fetchall()
    return jsonify({
        "receivedToday": float(received_today), "receivedMonth": float(received_month),
        "pendingCharges": pending, "paidCharges": paid,
        "recentCharges": [charge_json(row) for row in recent],
    })


@app.get("/api/charges")
@login_required
def list_charges():
    rows = get_db().execute("SELECT * FROM charges ORDER BY created_at DESC").fetchall()
    return jsonify([charge_json(row) for row in rows])


@app.post("/api/charges")
@login_required
def create_charge():
    payload = request.get_json(silent=True) or {}
    try:
        amount = round(float(payload.get("amount", 0)), 2)
    except (TypeError, ValueError):
        amount = 0
    if amount <= 0:
        return jsonify({"message": "Informe um valor maior que zero."}), 400
    txid = uuid4().hex
    try:
        pix = BancoDoBrasilPixClient().create_immediate_charge(
            txid=txid, amount=amount, description=str(payload.get("description", ""))[:100]
        )
    except PixIntegrationError as error:
        return jsonify({"message": str(error)}), 502
    created = now_iso()
    db = get_db()
    db.execute(
        """INSERT INTO charges
           (txid, payer_name, amount, description, status, pix_copy_paste, location, created_at, updated_at)
           VALUES (?, ?, ?, ?, 'ACTIVE', ?, ?, ?, ?)""",
        (txid, payload.get("payerName") or "Cliente não informado", amount, payload.get("description", ""), pix["pixCopyPaste"], pix.get("location"), created, created),
    )
    db.commit()
    row = db.execute("SELECT * FROM charges WHERE txid = ?", (txid,)).fetchone()
    return jsonify(charge_json(row)), 201


@app.get("/api/charges/<txid>")
@login_required
def get_charge(txid: str):
    db = get_db()
    row = db.execute("SELECT * FROM charges WHERE txid = ?", (txid,)).fetchone()
    if not row:
        return jsonify({"message": "Cobrança não encontrada."}), 404
    receipt_exists = db.execute("SELECT 1 FROM receipts WHERE txid = ? LIMIT 1", (txid,)).fetchone()
    if row["status"] == "PAID" and receipt_exists:
        return jsonify(charge_json(row))
    try:
        sync_charge_with_bb(db, row, BancoDoBrasilPixClient())
        db.commit()
        row = db.execute("SELECT * FROM charges WHERE txid = ?", (txid,)).fetchone()
    except PixIntegrationError:
        db.rollback()
        pass
    return jsonify(charge_json(row))


@app.post("/api/pix/sync")
@login_required
def sync_pix():
    """Sincroniza cobranças abertas quando o webhook não alcança o ambiente local."""
    db = get_db()
    rows = db.execute(
        """SELECT * FROM charges
           WHERE status = 'ACTIVE'
              OR (status = 'PAID' AND NOT EXISTS (
                    SELECT 1 FROM receipts WHERE receipts.txid = charges.txid
                 ))
           ORDER BY created_at DESC LIMIT 30"""
    ).fetchall()
    client = BancoDoBrasilPixClient()
    checked = 0
    new_receipts = 0
    failures = 0
    try:
        for payment in client.list_received_pix():
            if save_bb_payment(db, payment):
                new_receipts += 1
        checked += 1
    except PixIntegrationError:
        failures += 1
    for row in rows:
        try:
            new_receipts += sync_charge_with_bb(db, row, client)
            checked += 1
        except PixIntegrationError:
            failures += 1
    db.commit()
    return jsonify({
        "checked": checked,
        "newReceipts": new_receipts,
        "failures": failures,
    })


@app.get("/api/receipts")
@login_required
def list_receipts():
    query = request.args.get("q", "").strip()
    params: list[str] = []
    sql = "SELECT * FROM receipts"
    if query:
        sql += " WHERE payer_name LIKE ? OR txid LIKE ? OR e2eid LIKE ?"
        params.extend([f"%{query}%"] * 3)
    sql += " ORDER BY received_at DESC"
    rows = get_db().execute(sql, params).fetchall()
    return jsonify([receipt_json(row) for row in rows])


@app.post("/api/webhooks/bb/pix")
def bb_pix_webhook():
    expected = os.getenv("BB_WEBHOOK_SECRET")
    if expected and request.headers.get("X-Webhook-Secret") != expected:
        return jsonify({"message": "Origem não autorizada."}), 401
    payload = request.get_json(silent=True) or {}
    events = payload.get("pix", payload if isinstance(payload, list) else [])
    if not isinstance(events, list):
        return jsonify({"message": "Payload inválido."}), 400
    db = get_db()
    processed = 0
    for event in events:
        if save_bb_payment(db, event):
            processed += 1
    db.commit()
    return jsonify({"processed": processed}), 200


FRONTEND_DIST = BASE_DIR.parent / "frontend" / "dist"


@app.errorhandler(404)
def frontend(error):
    path = request.path.lstrip("/")
    if request.method != "GET" or path.startswith("api/") or not FRONTEND_DIST.is_dir():
        return error
    if path and (FRONTEND_DIST / path).is_file():
        return send_from_directory(FRONTEND_DIST, path)
    return send_from_directory(FRONTEND_DIST, "index.html")


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
